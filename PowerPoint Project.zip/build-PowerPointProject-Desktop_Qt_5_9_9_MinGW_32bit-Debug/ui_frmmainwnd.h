/********************************************************************************
** Form generated from reading UI file 'frmmainwnd.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRMMAINWND_H
#define UI_FRMMAINWND_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDockWidget>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QUndoView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_frmMainWnd
{
public:
    QAction *actionNew;
    QAction *actionOpen;
    QAction *actionSave;
    QAction *actionClose;
    QAction *actionAddCircle;
    QAction *actionAddRectangle;
    QAction *actionAddTriangle;
    QAction *actionAddLine;
    QAction *actionRemoveShape;
    QAction *HelpAction;
    QAction *SlideViewAction;
    QAction *NewSlideAction;
    QAction *RemoveSlideAction;
    QAction *actionColor;
    QAction *actionExportImage;
    QAction *actionText;
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout;
    QStackedWidget *DocumentArea;
    QWidget *page;
    QUndoView *undoView;
    QMenuBar *menubar;
    QMenu *menuFile;
    QMenu *menuShape;
    QMenu *menuHelp;
    QMenu *menuView;
    QStatusBar *statusbar;
    QToolBar *toolBar;
    QDockWidget *SlideDock;
    QWidget *dockWidgetContents;
    QHBoxLayout *horizontalLayout_2;
    QFormLayout *formLayout;
    QTableWidget *tbl_Slide;

    void setupUi(QMainWindow *frmMainWnd)
    {
        if (frmMainWnd->objectName().isEmpty())
            frmMainWnd->setObjectName(QStringLiteral("frmMainWnd"));
        frmMainWnd->resize(597, 326);
        QIcon icon;
        icon.addFile(QStringLiteral(":/Resource/icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        frmMainWnd->setWindowIcon(icon);
        actionNew = new QAction(frmMainWnd);
        actionNew->setObjectName(QStringLiteral("actionNew"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/Resource/filenew.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionNew->setIcon(icon1);
        actionOpen = new QAction(frmMainWnd);
        actionOpen->setObjectName(QStringLiteral("actionOpen"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/Resource/fileopen.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionOpen->setIcon(icon2);
        actionSave = new QAction(frmMainWnd);
        actionSave->setObjectName(QStringLiteral("actionSave"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/Resource/filesave.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave->setIcon(icon3);
        actionClose = new QAction(frmMainWnd);
        actionClose->setObjectName(QStringLiteral("actionClose"));
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/Resource/exit.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionClose->setIcon(icon4);
        actionAddCircle = new QAction(frmMainWnd);
        actionAddCircle->setObjectName(QStringLiteral("actionAddCircle"));
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/Resource/circle.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAddCircle->setIcon(icon5);
        actionAddRectangle = new QAction(frmMainWnd);
        actionAddRectangle->setObjectName(QStringLiteral("actionAddRectangle"));
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/Resource/rectangle.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAddRectangle->setIcon(icon6);
        actionAddTriangle = new QAction(frmMainWnd);
        actionAddTriangle->setObjectName(QStringLiteral("actionAddTriangle"));
        QIcon icon7;
        icon7.addFile(QStringLiteral(":/Resource/triangle.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAddTriangle->setIcon(icon7);
        actionAddLine = new QAction(frmMainWnd);
        actionAddLine->setObjectName(QStringLiteral("actionAddLine"));
        QIcon icon8;
        icon8.addFile(QStringLiteral(":/Resource/line.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAddLine->setIcon(icon8);
        actionRemoveShape = new QAction(frmMainWnd);
        actionRemoveShape->setObjectName(QStringLiteral("actionRemoveShape"));
        QIcon icon9;
        icon9.addFile(QStringLiteral(":/Resource/slideclose.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionRemoveShape->setIcon(icon9);
        HelpAction = new QAction(frmMainWnd);
        HelpAction->setObjectName(QStringLiteral("HelpAction"));
        SlideViewAction = new QAction(frmMainWnd);
        SlideViewAction->setObjectName(QStringLiteral("SlideViewAction"));
        SlideViewAction->setCheckable(true);
        NewSlideAction = new QAction(frmMainWnd);
        NewSlideAction->setObjectName(QStringLiteral("NewSlideAction"));
        QIcon icon10;
        icon10.addFile(QStringLiteral(":/Resource/slidenew.png"), QSize(), QIcon::Normal, QIcon::Off);
        NewSlideAction->setIcon(icon10);
        RemoveSlideAction = new QAction(frmMainWnd);
        RemoveSlideAction->setObjectName(QStringLiteral("RemoveSlideAction"));
        QIcon icon11;
        icon11.addFile(QStringLiteral(":/Resource/fileclose.png"), QSize(), QIcon::Normal, QIcon::Off);
        RemoveSlideAction->setIcon(icon11);
        actionColor = new QAction(frmMainWnd);
        actionColor->setObjectName(QStringLiteral("actionColor"));
        QIcon icon12;
        icon12.addFile(QStringLiteral(":/Resource/colorbutton.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionColor->setIcon(icon12);
        actionExportImage = new QAction(frmMainWnd);
        actionExportImage->setObjectName(QStringLiteral("actionExportImage"));
        QIcon icon13;
        icon13.addFile(QStringLiteral(":/Resource/gallery.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionExportImage->setIcon(icon13);
        actionText = new QAction(frmMainWnd);
        actionText->setObjectName(QStringLiteral("actionText"));
        QIcon icon14;
        icon14.addFile(QStringLiteral(":/Resource/text.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionText->setIcon(icon14);
        centralwidget = new QWidget(frmMainWnd);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        horizontalLayout = new QHBoxLayout(centralwidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        DocumentArea = new QStackedWidget(centralwidget);
        DocumentArea->setObjectName(QStringLiteral("DocumentArea"));
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        DocumentArea->addWidget(page);

        horizontalLayout->addWidget(DocumentArea);

        undoView = new QUndoView(centralwidget);
        undoView->setObjectName(QStringLiteral("undoView"));

        horizontalLayout->addWidget(undoView);

        frmMainWnd->setCentralWidget(centralwidget);
        menubar = new QMenuBar(frmMainWnd);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 597, 25));
        menuFile = new QMenu(menubar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        menuShape = new QMenu(menubar);
        menuShape->setObjectName(QStringLiteral("menuShape"));
        menuHelp = new QMenu(menubar);
        menuHelp->setObjectName(QStringLiteral("menuHelp"));
        menuView = new QMenu(menubar);
        menuView->setObjectName(QStringLiteral("menuView"));
        frmMainWnd->setMenuBar(menubar);
        statusbar = new QStatusBar(frmMainWnd);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        frmMainWnd->setStatusBar(statusbar);
        toolBar = new QToolBar(frmMainWnd);
        toolBar->setObjectName(QStringLiteral("toolBar"));
        toolBar->setIconSize(QSize(32, 32));
        frmMainWnd->addToolBar(Qt::TopToolBarArea, toolBar);
        SlideDock = new QDockWidget(frmMainWnd);
        SlideDock->setObjectName(QStringLiteral("SlideDock"));
        SlideDock->setMinimumSize(QSize(300, 129));
        SlideDock->setMaximumSize(QSize(300, 524287));
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QStringLiteral("dockWidgetContents"));
        horizontalLayout_2 = new QHBoxLayout(dockWidgetContents);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        formLayout = new QFormLayout();
        formLayout->setObjectName(QStringLiteral("formLayout"));

        horizontalLayout_2->addLayout(formLayout);

        tbl_Slide = new QTableWidget(dockWidgetContents);
        tbl_Slide->setObjectName(QStringLiteral("tbl_Slide"));

        horizontalLayout_2->addWidget(tbl_Slide);

        SlideDock->setWidget(dockWidgetContents);
        frmMainWnd->addDockWidget(static_cast<Qt::DockWidgetArea>(1), SlideDock);

        menubar->addAction(menuFile->menuAction());
        menubar->addAction(menuShape->menuAction());
        menubar->addAction(menuView->menuAction());
        menubar->addAction(menuHelp->menuAction());
        menuFile->addAction(actionNew);
        menuFile->addAction(actionOpen);
        menuFile->addAction(actionSave);
        menuFile->addAction(actionExportImage);
        menuFile->addSeparator();
        menuFile->addAction(actionClose);
        menuFile->addSeparator();
        menuShape->addSeparator();
        menuShape->addAction(NewSlideAction);
        menuShape->addAction(RemoveSlideAction);
        menuShape->addSeparator();
        menuShape->addAction(actionAddCircle);
        menuShape->addAction(actionAddRectangle);
        menuShape->addAction(actionAddTriangle);
        menuShape->addAction(actionAddLine);
        menuShape->addAction(actionRemoveShape);
        menuHelp->addAction(HelpAction);
        menuView->addAction(SlideViewAction);
        toolBar->addAction(actionNew);
        toolBar->addAction(actionOpen);
        toolBar->addAction(actionSave);
        toolBar->addAction(actionExportImage);
        toolBar->addAction(actionClose);
        toolBar->addSeparator();
        toolBar->addAction(NewSlideAction);
        toolBar->addAction(RemoveSlideAction);
        toolBar->addSeparator();
        toolBar->addAction(actionAddCircle);
        toolBar->addAction(actionAddRectangle);
        toolBar->addAction(actionAddTriangle);
        toolBar->addAction(actionAddLine);
        toolBar->addAction(actionRemoveShape);
        toolBar->addSeparator();
        toolBar->addAction(actionText);
        toolBar->addAction(actionColor);

        retranslateUi(frmMainWnd);

        QMetaObject::connectSlotsByName(frmMainWnd);
    } // setupUi

    void retranslateUi(QMainWindow *frmMainWnd)
    {
        frmMainWnd->setWindowTitle(QApplication::translate("frmMainWnd", "frmMainWnd", Q_NULLPTR));
        actionNew->setText(QApplication::translate("frmMainWnd", "&New", Q_NULLPTR));
        actionOpen->setText(QApplication::translate("frmMainWnd", "&Open", Q_NULLPTR));
        actionSave->setText(QApplication::translate("frmMainWnd", "&Save", Q_NULLPTR));
        actionClose->setText(QApplication::translate("frmMainWnd", "E&xit", Q_NULLPTR));
        actionAddCircle->setText(QApplication::translate("frmMainWnd", "Add Circle", Q_NULLPTR));
        actionAddRectangle->setText(QApplication::translate("frmMainWnd", "Add Rectangle", Q_NULLPTR));
        actionAddTriangle->setText(QApplication::translate("frmMainWnd", "Add Triangle", Q_NULLPTR));
        actionAddLine->setText(QApplication::translate("frmMainWnd", "Add Line", Q_NULLPTR));
        actionRemoveShape->setText(QApplication::translate("frmMainWnd", "Remove Shape", Q_NULLPTR));
        HelpAction->setText(QApplication::translate("frmMainWnd", "About", Q_NULLPTR));
        SlideViewAction->setText(QApplication::translate("frmMainWnd", "Slide", Q_NULLPTR));
        NewSlideAction->setText(QApplication::translate("frmMainWnd", "New Slide", Q_NULLPTR));
        RemoveSlideAction->setText(QApplication::translate("frmMainWnd", "Remove Slide", Q_NULLPTR));
        actionColor->setText(QApplication::translate("frmMainWnd", "Color", Q_NULLPTR));
        actionExportImage->setText(QApplication::translate("frmMainWnd", "Export Image", Q_NULLPTR));
        actionText->setText(QApplication::translate("frmMainWnd", "Text", Q_NULLPTR));
        menuFile->setTitle(QApplication::translate("frmMainWnd", "File", Q_NULLPTR));
        menuShape->setTitle(QApplication::translate("frmMainWnd", "Edit", Q_NULLPTR));
        menuHelp->setTitle(QApplication::translate("frmMainWnd", "Help", Q_NULLPTR));
        menuView->setTitle(QApplication::translate("frmMainWnd", "View", Q_NULLPTR));
        toolBar->setWindowTitle(QApplication::translate("frmMainWnd", "toolBar", Q_NULLPTR));
#ifndef QT_NO_STATUSTIP
        SlideDock->setStatusTip(QString());
#endif // QT_NO_STATUSTIP
        SlideDock->setWindowTitle(QApplication::translate("frmMainWnd", "Slides", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class frmMainWnd: public Ui_frmMainWnd {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRMMAINWND_H
