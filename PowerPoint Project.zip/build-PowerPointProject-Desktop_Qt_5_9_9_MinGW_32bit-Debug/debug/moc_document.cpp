/****************************************************************************
** Meta object code from reading C++ file 'document.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../PowerPointProject/document.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'document.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Document_t {
    QByteArrayData data[16];
    char stringdata0[264];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Document_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Document_t qt_meta_stringdata_Document = {
    {
QT_MOC_LITERAL(0, 0, 8), // "Document"
QT_MOC_LITERAL(1, 9, 19), // "currentShapeChanged"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 9), // "shapeName"
QT_MOC_LITERAL(4, 40, 23), // "currentShapetextChanged"
QT_MOC_LITERAL(5, 64, 9), // "shapeText"
QT_MOC_LITERAL(6, 74, 24), // "currentShapeColorChanged"
QT_MOC_LITERAL(7, 99, 10), // "shapeColor"
QT_MOC_LITERAL(8, 110, 27), // "currentShapePenstyleChanged"
QT_MOC_LITERAL(9, 138, 8), // "penstype"
QT_MOC_LITERAL(10, 147, 28), // "currentShapePenweightChanged"
QT_MOC_LITERAL(11, 176, 9), // "penweight"
QT_MOC_LITERAL(12, 186, 29), // "currentShapeFontfamilyChanged"
QT_MOC_LITERAL(13, 216, 10), // "fontfamily"
QT_MOC_LITERAL(14, 227, 27), // "currentShapeFontsizeChanged"
QT_MOC_LITERAL(15, 255, 8) // "fontsize"

    },
    "Document\0currentShapeChanged\0\0shapeName\0"
    "currentShapetextChanged\0shapeText\0"
    "currentShapeColorChanged\0shapeColor\0"
    "currentShapePenstyleChanged\0penstype\0"
    "currentShapePenweightChanged\0penweight\0"
    "currentShapeFontfamilyChanged\0fontfamily\0"
    "currentShapeFontsizeChanged\0fontsize"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Document[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   49,    2, 0x06 /* Public */,
       4,    1,   52,    2, 0x06 /* Public */,
       6,    1,   55,    2, 0x06 /* Public */,
       8,    1,   58,    2, 0x06 /* Public */,
      10,    1,   61,    2, 0x06 /* Public */,
      12,    1,   64,    2, 0x06 /* Public */,
      14,    1,   67,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QColor,    7,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void, QMetaType::Int,   15,

       0        // eod
};

void Document::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Document *_t = static_cast<Document *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->currentShapeChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->currentShapetextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->currentShapeColorChanged((*reinterpret_cast< const QColor(*)>(_a[1]))); break;
        case 3: _t->currentShapePenstyleChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->currentShapePenweightChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->currentShapeFontfamilyChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: _t->currentShapeFontsizeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (Document::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Document::currentShapeChanged)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (Document::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Document::currentShapetextChanged)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (Document::*_t)(const QColor & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Document::currentShapeColorChanged)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (Document::*_t)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Document::currentShapePenstyleChanged)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (Document::*_t)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Document::currentShapePenweightChanged)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (Document::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Document::currentShapeFontfamilyChanged)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (Document::*_t)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Document::currentShapeFontsizeChanged)) {
                *result = 6;
                return;
            }
        }
    }
}

const QMetaObject Document::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_Document.data,
      qt_meta_data_Document,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *Document::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Document::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Document.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Document::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void Document::currentShapeChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Document::currentShapetextChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Document::currentShapeColorChanged(const QColor & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Document::currentShapePenstyleChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void Document::currentShapePenweightChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void Document::currentShapeFontfamilyChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void Document::currentShapeFontsizeChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
